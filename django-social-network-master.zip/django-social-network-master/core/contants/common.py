FRIEND_REQUEST_VERB = "friend_request"
COMMENT_VERB = "comment"
LIKE_VERB = "like"
